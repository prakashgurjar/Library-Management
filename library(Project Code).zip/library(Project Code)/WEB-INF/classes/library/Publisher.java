package library;

import java.sql.*;

public class Publisher {
	
	private String label="olmspub";
	private String publisherid="";
	private String publisherName="";
	ResultSet rst;
	Database db=new Database();
	
	public ResultSet getAll()
	{
		rst=db.getData("select * from publisher");
		return rst;
	}
	
	public String getMaxPubid()
	{
		try
        {
      	    	int current=0,max=99;
      	    	rst=db.getData("select publisherid from publisher");
         	    while(rst.next())
         	    {
         	    	current=Integer.parseInt(rst.getString(1).substring(7));
         	    	if(current>max)
         	    		max=current;
         	    }
      	    	publisherid=label+(max+1);
		        db.close();
        }
        catch(SQLException e)
        {
      	  e.printStackTrace();
        }
		return publisherid;
	}

	public void add(String pubid,String pubname,String address,String city,String state,String pin,String phone,String email)
	{
		db.setData("insert into publisher values('"+pubid+"','"+pubname+"','"+address+"','"+city+"','"+state+"','"+pin+"','"+phone+"','"+email+"')");
		db.close();
	}
	
	public void update(String pubid,String pubname,String address,String city,String state,String pin,String phone,String email)
	{
		db.setData("update publisher set publishername='"+pubname+"',address='"+address+"',city='"+city+"',state='"+state+"',pin='"+pin+"',mobileno='"+phone+"',email='"+email+"' where publisherid='"+pubid+"'");
		db.close();
	}
	
	public void delete(String pubid)
	{
		db.setData("delete from publisher where publisherid='"+pubid+"'");
		db.close();
	}
	
	public ResultSet getDetail(String pubid)
	{
		rst=db.getData("select * from publisher where publisherid='"+pubid+"'");
		return rst;
	}
	
	public ResultSet getDetailSupplier(String pubid)
	{
		rst=db.getData("select * from supplier where publisherid='"+pubid+"'");
		return rst;
	}
	
	public ResultSet getSearchId(String pubid)
	{
		rst=db.getData("select * from publisher where publisherid='"+pubid+"'");
		return rst;
	}
	
	public ResultSet getSearchName(String pubname)
	{
		rst=db.getData("select * from publisher where publishername like '%"+pubname+"%'");
		return rst;
	}
}
