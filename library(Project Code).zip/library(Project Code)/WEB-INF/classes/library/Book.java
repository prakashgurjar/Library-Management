package library;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.*;

public class Book {
	
	private String label="olmsbook";
	private String bookid="";
	private String bookName="";
	ResultSet rst;
	Database db=new Database();
	
	public ResultSet getAll()
	{
		rst=db.getData("select * from book");
		return rst;
	}
	
	public String getMaxBookid()
	{
		try
        {
      	    	int current=0,max=99;
      	    	rst=db.getData("select bookid from book");
         	    while(rst.next())
         	    {
         	    	current=Integer.parseInt(rst.getString(1).substring(8));
         	    	if(current>max)
         	    		max=current;
         	    }
      	    	bookid=label+(max+1);
		        db.close();
        }
        catch(SQLException e)
        {
      	  e.printStackTrace();
        }
		return bookid;
	}

	public void add(String value[],String imagepath)
	{
		System.out.println(imagepath);
		db.setData("insert into book values('"+value[0]+"','"+value[1]+"','"+value[2]+"','"+value[3]+"','"+value[4]+"','"+value[5]+"','"+Integer.parseInt(value[6])+"','"+Integer.parseInt(value[7])+"','"+Integer.parseInt(value[8])+"','"+imagepath+"','"+value[9]+"','"+Integer.parseInt(value[10])+"')");
		db.close();
	}
	
	public void update(String value[],String imagepath)
	{
		db.setData("update book set bookname='"+value[1]+"',categoryid='"+value[2]+"',supplierid='"+value[3]+"',authorname='"+value[4]+"',isbn='"+value[5]+"',editionno='"+Integer.parseInt(value[6])+"',editionyear='"+Integer.parseInt(value[7])+"',price='"+Integer.parseInt(value[8])+"',imagepath='"+imagepath+"',description='"+value[9]+"',stock="+Integer.parseInt(value[10])+" where bookid='"+value[0]+"'");
		db.close();
	}
	       	
	public void delete(String bookid)
	{
		String imagepath="";
		rst=db.getData("select imagepath from book where bookid='"+bookid+"'");
		try
        {
         	    rst.next();
         	    imagepath=rst.getString(1);
        }
        catch(SQLException e)
        {
      	  e.printStackTrace();
        }
		File file=new File(imagepath);
		file.delete();
		db.setData("delete from book where bookid='"+bookid+"'");
		db.close();
	}
	
	public ResultSet getDetail(String bookid)
	{
		rst=db.getData("select * from book where bookid='"+bookid+"'");
		return rst;
	}
	
	public String getCategoryName(String categoryid)
	{
		String categoryname="";
		try
        {
      	    	rst=db.getData("select categoryname from category where categoryid='"+categoryid+"'");
         	    rst.next();
         	    categoryname=rst.getString(1);
        }
        catch(SQLException e)
        {
      	  e.printStackTrace();
        }
		db.close();
		return categoryname;
	}
	
	public String getSupplierName(String supplierid)
	{
		String suppliername="";
		try
        {
      	    	rst=db.getData("select suppliername from supplier where supplierid='"+supplierid+"'");
         	    rst.next();
         	   suppliername=rst.getString(1);
        }
        catch(SQLException e)
        {
      	  e.printStackTrace();
        }
		db.close();
		return suppliername;
	}
	
	public ResultSet getAllCategoryNames()
	{
		rst=db.getData("select * from category");
		return rst;
	}

	public ResultSet getAllSupplierNames()
	{
		rst=db.getData("select supplierid,suppliername from supplier");
		return rst;
	}
	
	public ResultSet getSearchId(String bookid)
	{
		rst=db.getData("select * from book where bookid='"+bookid+"'");
		return rst;
	}
	
	public ResultSet getSearchName(String bookname)
	{
		rst=db.getData("select * from book where bookname like '%"+bookname+"%'");
		return rst;
	}
}
