package library;
import java.sql.*;
import java.util.*;

public class Category {
	
	private String label="olmscat";
	private String categoryid="";
	private String categoryname="";
	private java.sql.Date currentdate;
	private java.sql.Date otherdate;
	Database db=new Database();
	ResultSet rst;
	
	public ResultSet getAll()
	{
		rst=db.getData("select * from category");
		return rst;
	}
	
	public String getMaxcatid()
	{
		try
        {
      	    	int current=0,max=99;
      	    	rst=db.getData("select categoryid from category");
         	    while(rst.next())
         	    {
         	    	current=Integer.parseInt(rst.getString(1).substring(7));
         	    	if(current>max)
         	    		max=current;
         	    }
      	    	categoryid=label+(max+1);
		        db.close();
        }
        catch(SQLException e)
        {
      	  e.printStackTrace();
        }
		return categoryid;
	}
	
	public void add(String catid,String catname)
	{
		db.setData("insert into category values('"+catid+"','"+catname+"')");
		db.close();
	}

	public String getCatname(String catid)
	{
		rst=db.getData("select categoryname from category where categoryid='"+catid+"'");
		try
        {
      	    	rst.next();
      	    	categoryname=rst.getString(1);
		        db.close();
        }
        catch(SQLException e)
        {
      	  e.printStackTrace();
        }
		return categoryname;
	}
	
	public void update(String catid,String catname)
	{
		db.setData("update category set categoryname='"+catname+"' where categoryid='"+catid+"'");
		db.close();
	}
	
	public void delete(String catid)
	{
		db.setData("delete from category where categoryid='"+catid+"'");
		db.close();
	}
	
	public ResultSet getSearchId(String catid)
	{
		rst=db.getData("select * from category where categoryid='"+catid+"'");
		return rst;
	}
	
	public ResultSet getSearchName(String catname)
	{
		rst=db.getData("select * from category where categoryname like '%"+catname+"%'");
		return rst;
	}
	
	public void sendReminder()
	{
		Calendar cal=Calendar.getInstance();
		cal.add(Calendar.YEAR,-1900);
		currentdate=new java.sql.Date(cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DATE));
		cal.add(Calendar.DATE,5);
		otherdate=new java.sql.Date(cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DATE));
		cal.add(Calendar.DATE,-5);
		
		ResultSet rst=db.getData("select userid,email from users where userid in(select userid from issuedbook where tentative_returndate>='"+currentdate+"' and tentative_returndate<='"+otherdate+"')");
		String title="Reminder Message";
		SendMail sendMail;
		try
		{
			while(rst.next())
			{
				String mymsg="The book that is issued to your The Central Library id '"+rst.getString(1)+"' is going to complete its Issued Duration.Kindly return it before or on tentative return date otherwise you have to pay fine.Ingnore if already returned.";

				sendMail = new SendMail(rst.getString(2),title,mymsg);
				sendMail.send();
			}
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		
	}
	
	public void sendFine()
	{
		Calendar cal=Calendar.getInstance();
		cal.add(Calendar.YEAR,-1900);
		currentdate=new java.sql.Date(cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DATE));
		
		ResultSet rst=db.getData("select userid,email from users where userid in(select userid from issuedbook where tentative_returndate<'"+currentdate+"')");
		String title="Reminder Message";
		SendMail sendMail;
		try
		{
			while(rst.next())
			{
				String mymsg="The book that is issued to your The Central Library id '"+rst.getString(1)+"' had completed its Issued Duration.Kindly return it with fine.Ingnore if already returned.";

				sendMail = new SendMail(rst.getString(2),title,mymsg);
				sendMail.send();
			}
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		
	}
}
