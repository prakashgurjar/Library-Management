package library;
import java.util.*;
import java.sql.*;

public class LoginCheck{
	
	 private String label="login";
	 private java.sql.Date date;
	 private String time="";
	 private String day="";
	 Database db=new Database();
	 
	 public void logindetail()
	 {
			Calendar cal=Calendar.getInstance();
			cal.add(Calendar.YEAR,-1900);
			date=new java.sql.Date(cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DATE));
	        time=cal.get(Calendar.HOUR_OF_DAY)+":"+cal.get(Calendar.MINUTE)+":"+cal.get(Calendar.SECOND);
			switch(cal.get(Calendar.DAY_OF_WEEK))
				   {
				   	  case 5: 
				   	  	   day="Sunday";
				   	  	   break;
				   	  case 6: 
				   	  	   day="Monday";
				   	  	   break;
				   	  case 7: 
				   	  	   day="Tuesday";
				   	  	   break;
				   	  case 1: 
				   	  	   day="Wednesday";
				   	  	   break;
				   	  case 2: 
				   	  	   day="Thursday";
				   	  	   break;
				   	  case 3: 
				   	  	   day="Friday";
				   	  	   break;
				   	  case 4: 
				   	  	   day="Saturday";
				   	  	   break;
				   }
	 }
	 
	 public String check(String userid,String password,String usertype)
	 {
		  String msg="";
          ResultSet rst=db.getData("select * from users where userid='"+userid+"' and password='"+password+"' and usertype='"+usertype+"'");
          try
          {
        	  if(rst.next())
        	  {
        		  logindetail();
        		  java.sql.Date expdate=rst.getDate(11);
        		  if(date.before(expdate) || date.equals(expdate))
        		  {
        			  msg="Authorised";
        		  }
        		  else
        		  {
        			  msg="Your Library User Id is Expired.Please Renew It.";
        		  }
        	  }
        	  else
        	  {
        		    msg="Wrong userid or password or usertype.";
        	  }
        	 db.close();
          }
          catch(SQLException e)
          {
        	  e.printStackTrace();
          }
          return msg;
	 }
	 
	 public void insertloginDetails(String userid,String usertype)
	 { 
		 String loginid="";
		 try
         {
       	    	int current=0,max=99999;
       	    	ResultSet rst=db.getData("select loginid from logindetail");
          	    while(rst.next())
          	    {
          	    	String logid=rst.getString(1);
          	    	current=Integer.parseInt(logid.substring(5));
          	    	if(current>max)
          	    		max=current;
          	    }
       	    	loginid=label+(max+1);
		        db.close();
         }
         catch(SQLException e)
         {
       	  e.printStackTrace();
         }
		 logindetail();
		 db.setData("insert into logindetail values('"+loginid+"','"+userid+"','"+usertype+"','"+date+"','"+time+"','"+day+"')");
	 }

}
