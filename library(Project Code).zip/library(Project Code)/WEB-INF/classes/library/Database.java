package library;
import java.sql.*;

import javax.swing.JOptionPane;

public class Database {
	        
	Connection conn;
	Statement stmt;
	ResultSet rst;
	int cnt;

	public Database() 
	{
	   setData("create table if not exists users(username varchar(20),fathername varchar(20),dob date,gender enum('Male','Female'),userid varchar(20) primary key,password varchar(15) not null,usertype enum('Admin','Student','Staff'),address varchar(255),mobileno varchar(15),email varchar(50),exp_date date)");
	   setData("create table if not exists category(categoryid varchar(20) primary key,categoryname varchar(30))");
	   setData("create table if not exists publisher(publisherid varchar(20) primary key,publishername varchar(50),address varchar(255),city varchar(20),state varchar(20),pin varchar(10),mobileno varchar(15),email varchar(50))");
	   setData("create table if not exists supplier(supplierid varchar(20) primary key,suppliername varchar(50),publisherid varchar(20),address varchar(255),city varchar(20),state varchar(20),pin varchar(10),mobileno varchar(15),email varchar(50),constraint foreign key (publisherid) references publisher (publisherid))");
	   setData("create table if not exists book(bookid varchar(20) primary key,bookname varchar(100),categoryid varchar(20),supplierid varchar(20),authorname varchar(255),isbn varchar(20),editionno int,editionyear int,price int,imagepath varchar(255),description varchar(255),stock int default '0',constraint foreign key (categoryid) references category (categoryid),constraint foreign key (supplierid) references supplier (supplierid))");
	   setData("create table if not exists reservedbook(reserveid int primary key,userid varchar(20),bookid varchar(20),reservedate date,constraint foreign key (userid) references users (userid),constraint foreign key (bookid) references book (bookid))");  // constraint foreign key (userid) references users (userid),
	   setData("create table if not exists issuedbook(issueid int primary key,userid varchar(20),bookid varchar(20),reservedate date,issuedate date,tentative_returndate date,constraint foreign key (userid) references users (userid),constraint foreign key (bookid) references book (bookid))");
	   setData("create table if not exists returnedbook(returnid int primary key,userid varchar(20),bookid varchar(20),reservedate date,issuedate date,tentative_returndate date,actual_returndate date ,fine int default '0',constraint foreign key (userid) references users (userid),constraint foreign key (bookid) references book (bookid))");
	   setData("create table if not exists query(queryid int primary key,userid varchar(20),subject varchar(255),query_description text,query_response text,constraint foreign key (userid) references users (userid))");
	   setData("create table if not exists logindetail(loginid varchar(20) primary key,userid varchar(20),usertype enum('Admin','Student','Staff'),login_date date,login_time time,login_day varchar(10),constraint foreign key (userid) references users (userid))");
	   setData("create table if not exists staff(staffid varchar(20) primary key,designation varchar(50),joiningdate date,salary int,worked_till date,constraint foreign key (staffid) references users (userid))");
	}
	
	public int setData(String query)
	{                                                                                                        
		try
		{
		       Class.forName("com.mysql.jdbc.Driver");
	           conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/onlinelibrary","root","");
	           stmt=conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
	           cnt=stmt.executeUpdate(query);
	           stmt.close();
	           conn.close();
		}	
		catch(ClassNotFoundException e)
		{
			JOptionPane.showMessageDialog(null,e,"Error",JOptionPane.ERROR_MESSAGE);
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			//JOptionPane.showMessageDialog(null,e,"Error",JOptionPane.ERROR_MESSAGE);
		}
		return cnt;
	}
	
	public ResultSet getData(String query)
	{
		try
		{
		       Class.forName("com.mysql.jdbc.Driver");
	           conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/onlinelibrary","root","");
	           stmt=conn.createStatement();
	           rst=stmt.executeQuery(query);
		}	
		catch(ClassNotFoundException e)
		{
			JOptionPane.showMessageDialog(null,e,"Error",JOptionPane.ERROR_MESSAGE);
		}
		catch(SQLException e)
		{
			// JOptionPane.showMessageDialog(null,e,"Error",JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		return rst;
	}
	
	public void close()
	{
		try
		{			
			stmt.close();
			conn.close();
		}
		catch(SQLException e)
		{
			JOptionPane.showMessageDialog(null,e,"Error",JOptionPane.ERROR_MESSAGE);
		}
	}

}
