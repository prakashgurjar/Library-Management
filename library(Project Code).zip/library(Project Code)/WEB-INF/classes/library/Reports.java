package library;

import java.util.*;
import java.sql.*;

public class Reports {
	
	ResultSet rst;
    Database db=new Database();
	public String getBookName(String bookid)
	{
		String bookname="";
		rst=db.getData("select bookname from book where bookid='"+bookid+"'");
		try
		{
			rst.next();
			bookname=rst.getString(1);
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		return bookname;
	}
	
	public void issue(int reserveid)
	{
		Calendar cal=Calendar.getInstance();
		cal.add(Calendar.YEAR,-1900);
		java.sql.Date date=new java.sql.Date(cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DATE));
		cal.add(Calendar.DATE,60);
		java.sql.Date tentative_date=new java.sql.Date(cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DATE));
		cal.add(Calendar.DATE,-60);
		rst=db.getData("select * from reservedbook where reserveid="+reserveid+"");
		try
		{
			rst.next();
			db.setData("insert into issuedbook values("+rst.getInt(1)+",'"+rst.getString(2)+"','"+rst.getString(3)+"','"+rst.getString(4)+"','"+date+"','"+tentative_date+"')");
			db.setData("delete from reservedbook where reserveid="+reserveid);
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		db.close();
	}
	
	public void returned(int issueid)
	{
		int fine=0;
		Calendar cal=Calendar.getInstance();
		cal.add(Calendar.YEAR,-1900);
		java.sql.Date date=new java.sql.Date(cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DATE));
		rst=db.getData("select * from issuedbook where issueid="+issueid);
		try
		{
			rst.next();
			java.sql.Date tentative=rst.getDate(6);
			if(date.after(tentative))
			{
				int i=1,count=0;
				while(!(date.equals(tentative)))
				{
			        tentative=new java.sql.Date(tentative.getYear(),tentative.getMonth(),(tentative.getDate()+i));
			        count++;
				}
				fine=count*5;
			}
			db.setData("insert into returnedbook values("+rst.getInt(1)+",'"+rst.getString(2)+"','"+rst.getString(3)+"','"+rst.getString(4)+"','"+rst.getString(5)+"','"+rst.getString(6)+"','"+date+"',"+fine+")");
			db.setData("delete from issuedbook where issueid="+issueid);
			
			String bookid=rst.getString(3);
			rst=db.getData("select stock from book where bookid='"+bookid+"'");
			rst.next();
			int stock=rst.getInt(1)+1;
	        db.setData("update book set stock="+stock+" where bookid='"+bookid+"'");
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		db.close();
	}
	
	public void delete(int returnid)
	{
		db.setData("delete from returnedbook where returnid="+returnid);
        db.close();
	}
	
	public ResultSet searchre(int reserveid)
	{
		rst=db.getData("select * from reservedbook where reserveid="+reserveid);
		return rst;
	}
	
	public ResultSet searchis(int issueid)
	{
		rst=db.getData("select * from issuedbook where issueid="+issueid);
		return rst;
	}
	
	public ResultSet searchret(int returnid)
	{
		rst=db.getData("select * from returnedbook where returnid="+returnid);
		return rst;
	}
}
