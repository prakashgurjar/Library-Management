package library;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class Users {
	
	private String label="olmsusers";
	private String userid="";
	private String userName="";
	ResultSet rst;
	Database db=new Database();
	
	public ResultSet getAll()
	{
		rst=db.getData("select * from users");
		return rst;
	}
	
	public ResultSet getStaff()
	{
		rst=db.getData("select userid from users where usertype='Staff' and userid not in(select staffid from staff)");
		return rst;
	}
	
	public ResultSet getAllStaff()
	{
		rst=db.getData("select * from staff");
		return rst;
	}
	
	public String getMaxUserid()
	{
		try
        {
      	    	int current=0,max=99;
      	    	rst=db.getData("select userid from users");
         	    while(rst.next())
         	    {
         	    	current=Integer.parseInt(rst.getString(1).substring(9));
         	    	if(current>max)
         	    		max=current;
         	    }
      	    	userid=label+(max+1);
		        db.close();
        }
        catch(SQLException e)
        {
      	  e.printStackTrace();
        }
		return userid;
	}

	public void add(String values[])
	{
		String password="";
		int capital=0;
		Random r=new Random();
		while(password.length()<8)
		{
			int number=(int)(r.nextDouble()*1000);
			if((number>=65 && number<=90 && capital<3)) 
		    {
		    	capital++;
		    	password+=(char)(number);
	     	}
	     	else if(number>=97 && number<=122)
	     	{
	     		password+=(char)(number);
	     	}	     		
		}
		
		db.setData("insert into users values('"+values[0]+"','"+values[1]+"','"+values[2]+"','"+values[3]+"','"+values[4]+"','"+password+"','"+values[5]+"','"+values[6]+"','"+values[7]+"','"+values[8]+"','"+values[9]+"')");
		db.close();
		
		String title="Account Information";
		String mymsg="Your account has been created on The Central Library online portal.Your User Id is '"+values[4]+"' ,Password is '"+password+"' ,User Type is '"+values[5]+"' and this account is valid till '"+values[9]+"' . Please login and view your profile.For further information contact us or send query.";

		SendMail sendMail = new SendMail(values[8],title,mymsg);
		sendMail.send();
	}
	
	public void addStaff(String values[])
	{
		db.setData("insert into staff values('"+values[0]+"','"+values[1]+"','"+values[2]+"',"+Integer.parseInt(values[3])+",'"+values[4]+"')");
		db.close();
	}
	
	public void update(String values[])
	{
		db.setData("update users set username='"+values[0]+"',fathername='"+values[1]+"',dob='"+values[2]+"',gender='"+values[3]+"',usertype='"+values[5]+"',address='"+values[6]+"',mobileno='"+values[7]+"',email='"+values[8]+"',exp_date='"+values[9]+"' where userid='"+values[4]+"'");
		db.close();
	}
	
	public void updateStaff(String values[])
	{
		db.setData("update staff set designation='"+values[1]+"',joiningdate='"+values[2]+"',salary="+Integer.parseInt(values[3])+",worked_till='"+values[4]+"' where staffid='"+values[0]+"'");
		db.close();
	}
	
	public void delete(String userid)
	{
		db.setData("delete from users where userid='"+userid+"'");
		db.close();
	}
	
	public void deleteStaff(String staffid)
	{
		db.setData("delete from staff where staffid='"+staffid+"'");
		db.close();
	}
	
	public ResultSet getDetail(String userid)
	{
		rst=db.getData("select * from users where userid='"+userid+"'");
		return rst;
	}
	
	public ResultSet getDetailStaff(String staffid)
	{
		rst=db.getData("select * from staff where staffid='"+staffid+"'");
		return rst;
	}
	
	public String getPublisherName(String publisherid)
	{
		String publishername="";
		try
        {
      	    	rst=db.getData("select publishername from publisher where publisherid='"+publisherid+"'");
         	    rst.next();
         	    publishername=rst.getString(1);
        }
        catch(SQLException e)
        {
      	  e.printStackTrace();
        }
		db.close();
		return publishername;
	}
	
	public ResultSet getAllPublisherNames()
	{
		rst=db.getData("select publisherid,publishername from publisher");
		return rst;
	}

	public ResultSet getSearchId(String userid)
	{
		rst=db.getData("select * from users where userid='"+userid+"'");
		return rst;
	}
	
	public ResultSet getSearchName(String username)
	{
		rst=db.getData("select * from users where username like '%"+username+"%'");
		return rst;
	}
}
