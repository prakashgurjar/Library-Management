package library;

import java.sql.ResultSet;
import java.sql.SQLException;

public class Supplier {
	
	private String label="olmssup";
	private String supplierid="";
	private String supplierName="";
	ResultSet rst;
	Database db=new Database();
	
	public ResultSet getAll()
	{
		rst=db.getData("select * from supplier");
		return rst;
	}
	
	public String getMaxSupid()
	{
		try
        {
      	    	int current=0,max=99;
      	    	rst=db.getData("select supplierid from supplier");
         	    while(rst.next())
         	    {
         	    	current=Integer.parseInt(rst.getString(1).substring(7));
         	    	if(current>max)
         	    		max=current;
         	    }
      	    	supplierid=label+(max+1);
		        db.close();
        }
        catch(SQLException e)
        {
      	  e.printStackTrace();
        }
		return supplierid;
	}

	public void add(String supid,String supname,String pubid,String address,String city,String state,String pin,String phone,String email)
	{
		db.setData("insert into supplier values('"+supid+"','"+supname+"','"+pubid+"','"+address+"','"+city+"','"+state+"','"+pin+"','"+phone+"','"+email+"')");
		db.close();
	}
	
	public void update(String supid,String supname,String pubid,String address,String city,String state,String pin,String phone,String email)
	{
		db.setData("update supplier set suppliername='"+supname+"',publisherid='"+pubid+"',address='"+address+"',city='"+city+"',state='"+state+"',pin='"+pin+"',mobileno='"+phone+"',email='"+email+"' where supplierid='"+supid+"'");
		db.close();
	}
	
	public void delete(String supid)
	{
		db.setData("delete from supplier where supplierid='"+supid+"'");
		db.close();
	}
	
	public ResultSet getDetail(String supid)
	{
		rst=db.getData("select * from supplier where supplierid='"+supid+"'");
		return rst;
	}
	
	public String getPublisherName(String publisherid)
	{
		String publishername="";
		try
        {
      	    	rst=db.getData("select publishername from publisher where publisherid='"+publisherid+"'");
         	    rst.next();
         	    publishername=rst.getString(1);
        }
        catch(SQLException e)
        {
      	  e.printStackTrace();
        }
		db.close();
		return publishername;
	}
	
	public ResultSet getAllPublisherNames()
	{
		rst=db.getData("select publisherid,publishername from publisher");
		return rst;
	}

	public ResultSet getSearchId(String supid)
	{
		rst=db.getData("select * from supplier where supplierid='"+supid+"'");
		return rst;
	}
	
	public ResultSet getSearchName(String supname)
	{
		rst=db.getData("select * from supplier where suppliername like '%"+supname+"%'");
		return rst;
	}
}
