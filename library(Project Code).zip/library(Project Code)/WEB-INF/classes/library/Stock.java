package library;

import java.sql.*;

public class Stock {
	
	String catname="";
	Database db=new Database();
	ResultSet rst;
	
	public String categoryName(String catid)
	{		
		rst=db.getData("select categoryname from category where categoryid='"+catid+"'");
		try
		{
			rst.next();
			catname=rst.getString(1);
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		return catname;
	}
	
	public void add(String bookid,int stock)
	{
		db.setData("update book set stock="+stock+" where bookid='"+bookid+"'");
	}

}
