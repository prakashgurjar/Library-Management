package library;

import java.sql.ResultSet;
import java.sql.SQLException;

public class Query {
	
	ResultSet rst;
	Database db=new Database();
	
	public ResultSet getAll()
	{
		rst=db.getData("select * from query");
		return rst;
	}
	
	public String getMailid(String userid)
	{
		String mailid="";
		rst=db.getData("select email from users where userid='"+userid+"'");
		try
        {
         	    rst.next();
      	    	mailid=rst.getString(1);
		        db.close();
        }
        catch(SQLException e)
        {
      	  e.printStackTrace();
        }
		return mailid;
	}
	
	public void delete(int queryid)
	{
		db.setData("delete from query where queryid="+queryid);
		db.close();
	}
}
