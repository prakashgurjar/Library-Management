package library;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import javax.mail.*;
import javax.mail.internet.*;

public class SendMail {
	
	private String from="centrallibrary007@gmail.com";
	private String to;
	private String subject;
	private String text;
	private String pass="skitbtech";
	private java.sql.Date currentdate;
	private java.sql.Date otherdate;
	
	Database db=new Database();
	
 	SendMail(String to, String subject, String text)
 	{
		this.to = to;
		this.subject = subject;
		this.text = text;
	}
	public void send()
	{
		try
		{
		
	  String host = "smtp.gmail.com";
	  Properties props = System.getProperties();
	  props.put("mail.smtp.starttls.enable", "true"); 
	  props.put("mail.smtp.host", host);
	  props.put("mail.smtp.user", from);
	  props.put("mail.smtp.password", pass);
	  props.put("mail.smtp.port", "587");
	  props.put("mail.smtp.auth", "true");
	  String[] tolist =new String[1];
	  tolist[0]=to;
	  Session session2 = Session.getDefaultInstance(props, null);
	  MimeMessage message = new MimeMessage(session2);
	  message.setFrom(new InternetAddress(from));
	  InternetAddress[] toAddress = new InternetAddress[tolist.length];
	
 
	  // To get the array of addresses
	  for( int i=0; i < tolist.length; i++ ) 
	  {                                                      
		// changed from a while loop
		toAddress[i] = new InternetAddress(tolist[i]);
	  }
 
 	  for( int i=0; i < toAddress.length; i++) 
	  { 
		// changed from a while loop
		message.addRecipient(Message.RecipientType.TO, toAddress[i]);
	  }
	  message.setSubject(subject);
	  message.setText(text);
	  Transport transport = session2.getTransport("smtp");
	  transport.connect(host, from, pass);
	  transport.sendMessage(message, message.getAllRecipients());
	  transport.close();
	    }
	    catch(MessagingException e)
	    {
	    	System.out.println(e);
	    }
	}

/*	public void sendReminder()
	{
		Calendar cal=Calendar.getInstance();
		cal.add(Calendar.YEAR,-1900);
		currentdate=new java.sql.Date(cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DATE));
		cal.add(Calendar.DATE,5);
		otherdate=new java.sql.Date(cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DATE));
		cal.add(Calendar.DATE,-5);
		
		ResultSet rst=db.getData("select userid,email from users where userid in(select userid from issuedbook where tentative_returndate>='"+currentdate+"' and tentative_returndate<='"+otherdate+"')");
		String title="Reminder Message";
		SendMail sendMail;
		try
		{
			while(rst.next())
			{
				String mymsg="The book that is issued to your The Central Library id '"+rst.getString(1)+"' is going to complete its Issued Duration.Kindly return it before or on tentative return date otherwise you have to pay fine.Ingnore if already returned.";

				sendMail = new SendMail(rst.getString(2),title,mymsg);
				sendMail.send();
			}
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		
	}
	
	public void sendFine()
	{
		Calendar cal=Calendar.getInstance();
		cal.add(Calendar.YEAR,-1900);
		currentdate=new java.sql.Date(cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DATE));
		
		ResultSet rst=db.getData("select userid,email from users where userid in(select userid from issuedbook where tentative_returndate<'"+currentdate+"')");
		String title="Reminder Message";
		SendMail sendMail;
		try
		{
			while(rst.next())
			{
				String mymsg="The book that is issued to your The Central Library id '"+rst.getString(1)+"' had completed its Issued Duration.Kindly return it with fine.Ingnore if already returned.";

				sendMail = new SendMail(rst.getString(2),title,mymsg);
				sendMail.send();
			}
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		
	}*/
}
